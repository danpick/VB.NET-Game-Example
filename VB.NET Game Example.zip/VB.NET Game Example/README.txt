#VB.NET Game Example

A very simple maze game developed in VB.NET 2008 as an example to show BTEC IT Students in preperation for creating their own games with VB.NET.

A simple prototype, but demonstrates some strong techniques such as control arrays, and picturebox collision events (bound intersects)

Any questions - danpick77@gmail.com