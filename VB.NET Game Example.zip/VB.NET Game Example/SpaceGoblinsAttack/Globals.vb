﻿Module Globals
    Public iSpeed As Integer
    Public iHealth As Integer
    Public iScore As Integer
End Module
