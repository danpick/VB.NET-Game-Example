﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLevel1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLevel1))
        Me.picAstronaut = New System.Windows.Forms.PictureBox
        Me.picMaze1 = New System.Windows.Forms.PictureBox
        Me.picMaze2 = New System.Windows.Forms.PictureBox
        Me.picMaze3 = New System.Windows.Forms.PictureBox
        Me.picMaze4 = New System.Windows.Forms.PictureBox
        Me.picFood1 = New System.Windows.Forms.PictureBox
        Me.picFood2 = New System.Windows.Forms.PictureBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblSpeed = New System.Windows.Forms.Label
        Me.picMaze5 = New System.Windows.Forms.PictureBox
        Me.picFood3 = New System.Windows.Forms.PictureBox
        Me.picMaze10 = New System.Windows.Forms.PictureBox
        Me.picMaze9 = New System.Windows.Forms.PictureBox
        Me.picMaze6 = New System.Windows.Forms.PictureBox
        Me.lblFinish = New System.Windows.Forms.Label
        Me.picMaze7 = New System.Windows.Forms.PictureBox
        Me.picMaze8 = New System.Windows.Forms.PictureBox
        Me.lblHealth = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblScore = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.picGoblin1 = New System.Windows.Forms.PictureBox
        Me.picGoblin2 = New System.Windows.Forms.PictureBox
        Me.picGate = New System.Windows.Forms.PictureBox
        CType(Me.picAstronaut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFood1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFood2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFood3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMaze8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGoblin1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGoblin2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picAstronaut
        '
        Me.picAstronaut.Image = CType(resources.GetObject("picAstronaut.Image"), System.Drawing.Image)
        Me.picAstronaut.InitialImage = Nothing
        Me.picAstronaut.Location = New System.Drawing.Point(40, 500)
        Me.picAstronaut.Name = "picAstronaut"
        Me.picAstronaut.Size = New System.Drawing.Size(40, 46)
        Me.picAstronaut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAstronaut.TabIndex = 2
        Me.picAstronaut.TabStop = False
        '
        'picMaze1
        '
        Me.picMaze1.BackColor = System.Drawing.Color.White
        Me.picMaze1.Location = New System.Drawing.Point(12, 41)
        Me.picMaze1.Name = "picMaze1"
        Me.picMaze1.Size = New System.Drawing.Size(10, 444)
        Me.picMaze1.TabIndex = 3
        Me.picMaze1.TabStop = False
        '
        'picMaze2
        '
        Me.picMaze2.BackColor = System.Drawing.Color.White
        Me.picMaze2.Location = New System.Drawing.Point(12, 41)
        Me.picMaze2.Name = "picMaze2"
        Me.picMaze2.Size = New System.Drawing.Size(762, 10)
        Me.picMaze2.TabIndex = 4
        Me.picMaze2.TabStop = False
        '
        'picMaze3
        '
        Me.picMaze3.BackColor = System.Drawing.Color.White
        Me.picMaze3.Location = New System.Drawing.Point(97, 552)
        Me.picMaze3.Name = "picMaze3"
        Me.picMaze3.Size = New System.Drawing.Size(677, 10)
        Me.picMaze3.TabIndex = 5
        Me.picMaze3.TabStop = False
        '
        'picMaze4
        '
        Me.picMaze4.BackColor = System.Drawing.Color.White
        Me.picMaze4.Location = New System.Drawing.Point(96, 121)
        Me.picMaze4.Name = "picMaze4"
        Me.picMaze4.Size = New System.Drawing.Size(10, 441)
        Me.picMaze4.TabIndex = 6
        Me.picMaze4.TabStop = False
        '
        'picFood1
        '
        Me.picFood1.Image = CType(resources.GetObject("picFood1.Image"), System.Drawing.Image)
        Me.picFood1.Location = New System.Drawing.Point(45, 380)
        Me.picFood1.Name = "picFood1"
        Me.picFood1.Size = New System.Drawing.Size(23, 25)
        Me.picFood1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFood1.TabIndex = 7
        Me.picFood1.TabStop = False
        '
        'picFood2
        '
        Me.picFood2.Image = CType(resources.GetObject("picFood2.Image"), System.Drawing.Image)
        Me.picFood2.Location = New System.Drawing.Point(28, 78)
        Me.picFood2.Name = "picFood2"
        Me.picFood2.Size = New System.Drawing.Size(23, 25)
        Me.picFood2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFood2.TabIndex = 8
        Me.picFood2.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(13, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(206, 17)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Astronaut Speed = "
        '
        'lblSpeed
        '
        Me.lblSpeed.AutoSize = True
        Me.lblSpeed.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSpeed.ForeColor = System.Drawing.Color.White
        Me.lblSpeed.Location = New System.Drawing.Point(212, 5)
        Me.lblSpeed.Name = "lblSpeed"
        Me.lblSpeed.Size = New System.Drawing.Size(19, 17)
        Me.lblSpeed.TabIndex = 10
        Me.lblSpeed.Text = "5"
        '
        'picMaze5
        '
        Me.picMaze5.BackColor = System.Drawing.Color.White
        Me.picMaze5.Location = New System.Drawing.Point(186, 41)
        Me.picMaze5.Name = "picMaze5"
        Me.picMaze5.Size = New System.Drawing.Size(10, 441)
        Me.picMaze5.TabIndex = 11
        Me.picMaze5.TabStop = False
        '
        'picFood3
        '
        Me.picFood3.Image = CType(resources.GetObject("picFood3.Image"), System.Drawing.Image)
        Me.picFood3.Location = New System.Drawing.Point(737, 78)
        Me.picFood3.Name = "picFood3"
        Me.picFood3.Size = New System.Drawing.Size(23, 25)
        Me.picFood3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFood3.TabIndex = 12
        Me.picFood3.TabStop = False
        '
        'picMaze10
        '
        Me.picMaze10.BackColor = System.Drawing.Color.White
        Me.picMaze10.Location = New System.Drawing.Point(279, 299)
        Me.picMaze10.Name = "picMaze10"
        Me.picMaze10.Size = New System.Drawing.Size(10, 262)
        Me.picMaze10.TabIndex = 13
        Me.picMaze10.TabStop = False
        '
        'picMaze9
        '
        Me.picMaze9.BackColor = System.Drawing.Color.White
        Me.picMaze9.Location = New System.Drawing.Point(279, 299)
        Me.picMaze9.Name = "picMaze9"
        Me.picMaze9.Size = New System.Drawing.Size(401, 12)
        Me.picMaze9.TabIndex = 14
        Me.picMaze9.TabStop = False
        '
        'picMaze6
        '
        Me.picMaze6.BackColor = System.Drawing.Color.White
        Me.picMaze6.Location = New System.Drawing.Point(186, 227)
        Me.picMaze6.Name = "picMaze6"
        Me.picMaze6.Size = New System.Drawing.Size(494, 12)
        Me.picMaze6.TabIndex = 15
        Me.picMaze6.TabStop = False
        '
        'lblFinish
        '
        Me.lblFinish.AutoSize = True
        Me.lblFinish.BackColor = System.Drawing.Color.White
        Me.lblFinish.Font = New System.Drawing.Font("OCR A Extended", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinish.Location = New System.Drawing.Point(305, 500)
        Me.lblFinish.Name = "lblFinish"
        Me.lblFinish.Size = New System.Drawing.Size(81, 20)
        Me.lblFinish.TabIndex = 16
        Me.lblFinish.Text = "Finish"
        '
        'picMaze7
        '
        Me.picMaze7.BackColor = System.Drawing.Color.White
        Me.picMaze7.Location = New System.Drawing.Point(280, 137)
        Me.picMaze7.Name = "picMaze7"
        Me.picMaze7.Size = New System.Drawing.Size(494, 12)
        Me.picMaze7.TabIndex = 17
        Me.picMaze7.TabStop = False
        '
        'picMaze8
        '
        Me.picMaze8.BackColor = System.Drawing.Color.White
        Me.picMaze8.Location = New System.Drawing.Point(771, 41)
        Me.picMaze8.Name = "picMaze8"
        Me.picMaze8.Size = New System.Drawing.Size(10, 521)
        Me.picMaze8.TabIndex = 18
        Me.picMaze8.TabStop = False
        '
        'lblHealth
        '
        Me.lblHealth.AutoSize = True
        Me.lblHealth.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHealth.ForeColor = System.Drawing.Color.White
        Me.lblHealth.Location = New System.Drawing.Point(480, 5)
        Me.lblHealth.Name = "lblHealth"
        Me.lblHealth.Size = New System.Drawing.Size(30, 17)
        Me.lblHealth.TabIndex = 20
        Me.lblHealth.Text = "10"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(276, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(217, 17)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Astronaut Health = "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(563, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 17)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Score ="
        '
        'lblScore
        '
        Me.lblScore.AutoSize = True
        Me.lblScore.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScore.ForeColor = System.Drawing.Color.White
        Me.lblScore.Location = New System.Drawing.Point(654, 5)
        Me.lblScore.Name = "lblScore"
        Me.lblScore.Size = New System.Drawing.Size(19, 17)
        Me.lblScore.TabIndex = 22
        Me.lblScore.Text = "0"
        '
        'Timer1
        '
        '
        'picGoblin1
        '
        Me.picGoblin1.Image = CType(resources.GetObject("picGoblin1.Image"), System.Drawing.Image)
        Me.picGoblin1.Location = New System.Drawing.Point(591, 352)
        Me.picGoblin1.Name = "picGoblin1"
        Me.picGoblin1.Size = New System.Drawing.Size(31, 32)
        Me.picGoblin1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picGoblin1.TabIndex = 23
        Me.picGoblin1.TabStop = False
        '
        'picGoblin2
        '
        Me.picGoblin2.Image = CType(resources.GetObject("picGoblin2.Image"), System.Drawing.Image)
        Me.picGoblin2.Location = New System.Drawing.Point(493, 479)
        Me.picGoblin2.Name = "picGoblin2"
        Me.picGoblin2.Size = New System.Drawing.Size(31, 32)
        Me.picGoblin2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picGoblin2.TabIndex = 24
        Me.picGoblin2.TabStop = False
        '
        'picGate
        '
        Me.picGate.BackColor = System.Drawing.Color.Gray
        Me.picGate.Location = New System.Drawing.Point(670, 310)
        Me.picGate.Name = "picGate"
        Me.picGate.Size = New System.Drawing.Size(10, 242)
        Me.picGate.TabIndex = 25
        Me.picGate.TabStop = False
        '
        'frmLevel1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(792, 573)
        Me.Controls.Add(Me.picGate)
        Me.Controls.Add(Me.picGoblin2)
        Me.Controls.Add(Me.picGoblin1)
        Me.Controls.Add(Me.lblScore)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblHealth)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.picMaze8)
        Me.Controls.Add(Me.picMaze7)
        Me.Controls.Add(Me.lblFinish)
        Me.Controls.Add(Me.picMaze6)
        Me.Controls.Add(Me.picMaze9)
        Me.Controls.Add(Me.picMaze10)
        Me.Controls.Add(Me.picFood3)
        Me.Controls.Add(Me.picMaze5)
        Me.Controls.Add(Me.lblSpeed)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.picFood2)
        Me.Controls.Add(Me.picFood1)
        Me.Controls.Add(Me.picMaze4)
        Me.Controls.Add(Me.picMaze3)
        Me.Controls.Add(Me.picMaze2)
        Me.Controls.Add(Me.picMaze1)
        Me.Controls.Add(Me.picAstronaut)
        Me.Name = "frmLevel1"
        Me.Text = "Form1"
        CType(Me.picAstronaut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFood1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFood2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFood3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMaze8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGoblin1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGoblin2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picAstronaut As System.Windows.Forms.PictureBox
    Friend WithEvents picMaze1 As System.Windows.Forms.PictureBox
    Friend WithEvents picMaze2 As System.Windows.Forms.PictureBox
    Friend WithEvents picMaze3 As System.Windows.Forms.PictureBox
    Friend WithEvents picMaze4 As System.Windows.Forms.PictureBox
    Friend WithEvents picFood1 As System.Windows.Forms.PictureBox
    Friend WithEvents picFood2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblSpeed As System.Windows.Forms.Label
    Friend WithEvents picMaze5 As System.Windows.Forms.PictureBox
    Friend WithEvents picFood3 As System.Windows.Forms.PictureBox
    Friend WithEvents picMaze10 As System.Windows.Forms.PictureBox
    Friend WithEvents picMaze9 As System.Windows.Forms.PictureBox
    Friend WithEvents picMaze6 As System.Windows.Forms.PictureBox
    Friend WithEvents lblFinish As System.Windows.Forms.Label
    Friend WithEvents picMaze7 As System.Windows.Forms.PictureBox
    Friend WithEvents picMaze8 As System.Windows.Forms.PictureBox
    Friend WithEvents lblHealth As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblScore As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents picGoblin1 As System.Windows.Forms.PictureBox
    Friend WithEvents picGoblin2 As System.Windows.Forms.PictureBox
    Friend WithEvents picGate As System.Windows.Forms.PictureBox

End Class
