﻿Public Class frmLevel1


    Dim bGoblin1Up As Boolean
    Dim bGoblin2Up As Boolean
    Dim iTime As Integer


    Private Sub frmLevel1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim picFood() As PictureBox = {picFood1, picFood2, picFood3}
        Dim picGoblin() As PictureBox = {picGoblin1, picGoblin2}
        Dim iLoop As Integer

        Timer1.Start()

        Me.Text = "Space Goblins Attack v" & Application.ProductVersion & " Level 1"
        Me.Top = 0
        Me.Left = 0

        'now inserted at design time 'DP 8/3/19
        'picAstronaut.ImageLocation = Application.StartupPath & "\Astronaut.png"
        'picAstronaut.SizeMode = PictureBoxSizeMode.StretchImage
        picAstronaut.Top = 500
        picAstronaut.Left = 40
        iSpeed = 5
        iHealth = 10
        iScore = 0

        'now inserted at design time 'DP 8/3/19
        'For iLoop = 0 To picFood.Length - 1
        '    picFood(iLoop).ImageLocation = Application.StartupPath & "\Donut.png"
        '    picFood(iLoop).SizeMode = PictureBoxSizeMode.StretchImage
        'Next

        For iLoop = 0 To picGoblin.Length - 1
            'all now inserted at design time 'DP 8/3/19
            'picGoblin(iLoop).ImageLocation = Application.StartupPath & "\Goblin" & iLoop + 1 & ".png"
            'picGoblin(iLoop).SizeMode = PictureBoxSizeMode.StretchImage
            picGoblin(iLoop).Visible = False
        Next
        bGoblin1Up = False
        bGoblin2up = True

    End Sub

    Private Sub frmLevel1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Dim iLoop As Integer
        Dim picMaze() As PictureBox = {picMaze1, picMaze2, picMaze3, picMaze4, picMaze5, picMaze6, picMaze7, picMaze8, picMaze9, picMaze10}
        Dim picFood() As PictureBox = {picFood1, picFood2, picFood3}
        ' Dim picGoblin() As PictureBox = {picGoblin1, picGoblin2}

        Select Case e.KeyCode
            Case Keys.Left
                If picAstronaut.Left > 0 Then
                    picAstronaut.Left = picAstronaut.Left - iSpeed
                End If
            Case Keys.Right
                If picAstronaut.Left < Me.Width Then
                    picAstronaut.Left = picAstronaut.Left + iSpeed
                End If
            Case Keys.Up
                If picAstronaut.Top > 0 Then
                    picAstronaut.Top = picAstronaut.Top - iSpeed
                End If
            Case Keys.Down
                If picAstronaut.Top < Me.Height Then
                    picAstronaut.Top = picAstronaut.Top + iSpeed
                End If
        End Select

        For iLoop = 0 To picMaze.Length - 1
            If picAstronaut.Bounds.IntersectsWith(picMaze(iLoop).Bounds) Then
                picAstronaut.Top = 500
                picAstronaut.Left = 40
                MsgBox("Mind the space city walls - try again!")
            End If
        Next iLoop

        
        For iLoop = 0 To picFood.Length - 1
            If picAstronaut.Bounds.IntersectsWith(picFood(iLoop).Bounds) Then
                picFood(iLoop).Top = 0
                picFood(iLoop).Left = 0
                picFood(iLoop).Hide()
                iSpeed = iSpeed + 5
                lblSpeed.Text = iSpeed
                iHealth = iHealth + 10
                lblHealth.Text = iHealth
                iScore = iScore + 20
                lblScore.Text = iScore
                If iScore = 60 Then
                    picGate.Top = 0
                    picGate.Left = 0
                    picGate.Visible = False
                    picGoblin1.Visible = True
                    picGoblin2.Visible = True

                End If
            End If
        Next iLoop

        If picAstronaut.Bounds.IntersectsWith(picGate.Bounds) Then
            picAstronaut.Top = 500
            picAstronaut.Left = 40
            MsgBox("You must collect all donuts in order to open the gate!")
        End If

        CheckGoblinCollision()

        If picAstronaut.Bounds.IntersectsWith(lblFinish.Bounds) Then
            MsgBox("Congratulations - you have finished the level!")
            'MsgBox(iTime)
            iScore = iScore + 20
            If iTime < 400 Then
                iScore = iScore + ((400 - iTime) / 10)
            End If
            lblScore.Text = iScore
            frmLevel2.Show()
            Me.Hide()
        End If

    End Sub


    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        If picGoblin1.Top <= 299 Then
            bGoblin1Up = False
        End If
        If picGoblin1.Top >= 532 Then
            bGoblin1Up = True
        End If

        If picGoblin2.Top <= 299 Then
            bGoblin2up = False
        End If
        If picGoblin2.Top >= 532 Then
            bGoblin2up = True
        End If

        If bGoblin1Up = True Then
            picGoblin1.Top = picGoblin1.Top - 10
        Else
            picGoblin1.Top = picGoblin1.Top + 10
        End If

        If bGoblin2up = True Then
            picGoblin2.Top = picGoblin2.Top - 10
        Else
            picGoblin2.Top = picGoblin2.Top + 10
        End If

        CheckGoblinCollision()

        iTime = iTime + 1

    End Sub

    Private Sub CheckGoblinCollision()

        Dim picGoblin() As PictureBox = {picGoblin1, picGoblin2}

        For iLoop = 0 To picGoblin.Length - 1 'ensures that if goblin collides with astronaut then collision takes place
            If picAstronaut.Bounds.IntersectsWith(picGoblin(iLoop).Bounds) Then
                picAstronaut.Top = 500
                picAstronaut.Left = 40
                iHealth = iHealth - 10
                lblHealth.Text = iHealth
                MsgBox("Mind the space goblins - they have swords!")
            End If
        Next iLoop
    End Sub


    Private Sub frmLevel1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        frmWelcome.Close()
        'frmLevel2.Close()
    End Sub

End Class
