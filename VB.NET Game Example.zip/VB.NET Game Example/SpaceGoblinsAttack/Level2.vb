﻿Public Class frmLevel2



    Private Sub frmLevel2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Space Goblins Attack v" & Application.ProductVersion & " Level 2"
        Me.Top = 0
        Me.Left = 0

        lblSpeed.Text = iSpeed
        lblHealth.Text = iHealth
        lblScore.Text = iScore

    End Sub

    Private Sub frmLevel2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        frmWelcome.Close()
        frmLevel1.Close()
    End Sub

End Class