﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWelcome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWelcome))
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblVersion = New System.Windows.Forms.Label
        Me.picAstronaut = New System.Windows.Forms.PictureBox
        Me.picFood = New System.Windows.Forms.PictureBox
        Me.picGoblin = New System.Windows.Forms.PictureBox
        Me.lblFinish = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.lblLoad = New System.Windows.Forms.Label
        CType(Me.picAstronaut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFood, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGoblin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(329, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(118, 17)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Welcome to"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("OCR A Extended", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(37, 74)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(712, 50)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Space Goblins Attack!!!"
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = True
        Me.lblVersion.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVersion.ForeColor = System.Drawing.Color.White
        Me.lblVersion.Location = New System.Drawing.Point(329, 162)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(118, 17)
        Me.lblVersion.TabIndex = 22
        Me.lblVersion.Text = "lblVersion"
        '
        'picAstronaut
        '
        Me.picAstronaut.Image = CType(resources.GetObject("picAstronaut.Image"), System.Drawing.Image)
        Me.picAstronaut.Location = New System.Drawing.Point(59, 201)
        Me.picAstronaut.Name = "picAstronaut"
        Me.picAstronaut.Size = New System.Drawing.Size(105, 94)
        Me.picAstronaut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAstronaut.TabIndex = 23
        Me.picAstronaut.TabStop = False
        '
        'picFood
        '
        Me.picFood.Image = CType(resources.GetObject("picFood.Image"), System.Drawing.Image)
        Me.picFood.Location = New System.Drawing.Point(286, 206)
        Me.picFood.Name = "picFood"
        Me.picFood.Size = New System.Drawing.Size(90, 84)
        Me.picFood.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFood.TabIndex = 24
        Me.picFood.TabStop = False
        '
        'picGoblin
        '
        Me.picGoblin.Image = CType(resources.GetObject("picGoblin.Image"), System.Drawing.Image)
        Me.picGoblin.Location = New System.Drawing.Point(472, 201)
        Me.picGoblin.Name = "picGoblin"
        Me.picGoblin.Size = New System.Drawing.Size(103, 94)
        Me.picGoblin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picGoblin.TabIndex = 25
        Me.picGoblin.TabStop = False
        '
        'lblFinish
        '
        Me.lblFinish.AutoSize = True
        Me.lblFinish.BackColor = System.Drawing.Color.White
        Me.lblFinish.Font = New System.Drawing.Font("OCR A Extended", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinish.Location = New System.Drawing.Point(656, 239)
        Me.lblFinish.Name = "lblFinish"
        Me.lblFinish.Size = New System.Drawing.Size(81, 20)
        Me.lblFinish.TabIndex = 26
        Me.lblFinish.Text = "Finish"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(43, 309)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(140, 68)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Control the " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "astronaut " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "using the " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "cursor keys"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(245, 309)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(184, 68)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Collect the " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "food to " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "increase health " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and score"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(452, 318)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(151, 51)
        Me.Label5.TabIndex = 29
        Me.Label5.Text = "Avoid the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Space Goblins" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "at all costs"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(641, 309)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(118, 68)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Reach the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "finish to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "get to the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "next level"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLoad
        '
        Me.lblLoad.AutoSize = True
        Me.lblLoad.Font = New System.Drawing.Font("OCR A Extended", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLoad.ForeColor = System.Drawing.Color.White
        Me.lblLoad.Location = New System.Drawing.Point(37, 452)
        Me.lblLoad.Name = "lblLoad"
        Me.lblLoad.Size = New System.Drawing.Size(682, 50)
        Me.lblLoad.TabIndex = 31
        Me.lblLoad.Text = "Click here to begin!!!"
        '
        'frmWelcome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(792, 573)
        Me.Controls.Add(Me.lblLoad)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblFinish)
        Me.Controls.Add(Me.picGoblin)
        Me.Controls.Add(Me.picFood)
        Me.Controls.Add(Me.picAstronaut)
        Me.Controls.Add(Me.lblVersion)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Name = "frmWelcome"
        Me.Text = "Welcome"
        CType(Me.picAstronaut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFood, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGoblin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents picAstronaut As System.Windows.Forms.PictureBox
    Friend WithEvents picFood As System.Windows.Forms.PictureBox
    Friend WithEvents picGoblin As System.Windows.Forms.PictureBox
    Friend WithEvents lblFinish As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblLoad As System.Windows.Forms.Label
End Class
