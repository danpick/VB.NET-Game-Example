﻿Public Class frmWelcome

    Private Sub frmWelcome_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'frmLevel1.Close()
        'frmLevel2.Close()
    End Sub

    Private Sub Welcome_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Space Goblins Attack v" & Application.ProductVersion
        Me.Top = 0
        Me.Left = 0

        lblVersion.Text = "v" & Application.ProductVersion

        'all now inserted at design time 'DP 8/3/19
        'picAstronaut.ImageLocation = Application.StartupPath & "\Astronaut.png"
        'picAstronaut.SizeMode = PictureBoxSizeMode.StretchImage

        'picFood.ImageLocation = Application.StartupPath & "\Donut.png"
        'picFood.SizeMode = PictureBoxSizeMode.StretchImage

        'picGoblin.ImageLocation = Application.StartupPath & "\Goblin1.png"
        'picGoblin.SizeMode = PictureBoxSizeMode.StretchImage


    End Sub



    Private Sub lblLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblLoad.Click

        frmLevel1.Show()
        Me.Hide()
    End Sub
End Class